import React from 'react'
import '../Landing.css';
import { Link } from 'react-router-dom';
import main from '../assets/images/business-people-discussing-business-idea.png'
import analise from '../assets/images/businessman-analyzing-data.png'
import team from '../assets/images/designer-team-working-on-creative-design.png'
import people1 from '../assets/images/western-man-4975942-4159828 1.png'
import people2 from '../assets/images/asian-woman-4975939-4159825 1.png'
import people3 from '../assets/images/black-woman-4975941-4159827 1.png'
import customer from '../assets/images/customer-support.png'
function Landing() {
  return (
    <>
    <header class="header1">
      <div class="logo">City Dashboard</div>
      <div class="nav">
        <ul class="menu">
          <li>
            <Link to='/'>Home</Link>
          </li>
          <li>
            <a href="#about">About</a>
          </li>
          <li>
            <a href="#testi">Testimonial</a>
          </li>
          <li>
            <a href="#contact">Contact</a>
          </li>
        </ul>
      </div>
      <div class="menu-btn">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          stroke-width="1.5"
          stroke="currentColor"
          class="w-6 h-6"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
          />
        </svg>
      </div>
    </header>
    <main>
      
      <section class="hero">
        <div class="title">
          <h1>Urban Insights: Your City Dashboard</h1>
          <p>
          Stay updated with real-time city data. Weather, traffic, events, and more at your fingertips with our intuitive city dashboard
          </p>
          <Link to='/app'>
          <button className='conbtn'>Get Started</button>
          </Link>
        </div>
        <div class="image">
          <img
        src={main}
            alt="alt"
          />
        </div>
      </section>
      

      <section class="about" id='about'>
        <div class="blur-2">
          <img src="images/Ellipse 3.png" alt="" />
        </div>
        <div class="aboutone">
          <div class="image">
            <img
              src={team}
              alt=""
            />
          </div>
          <div class="title">
            <h2>Interactive City Maps</h2>
            <p>
            Navigate through dynamic cityscapes with real-time latitude, longitude data, and seamless zoom features for immersive urban exploration.
            </p>
          </div>
        </div>
        <div class="aboutone">
          <div class="title">
            <h2>Weather Analytics Hub</h2>
            <p>
            Access comprehensive weather data, including historical insights and hourly forecasts, empowering informed decision-making for urban activities and planning.
            </p>
          </div>
          <div class="image">
            <img src={analise} alt="" />
          </div>
        </div>
      </section>

      <section class="testimonial" id='testi'>
        <p>Testimonial</p>
        <h2>Read What Other have to Say</h2>
        <div class="cards">
          <div class="card">
            <div class="image">
              <img className='setim' src={people1} alt="" />
            </div>
            <p class="name">Andrew Rathore</p>

            <p>
            From detailed maps for seamless navigation to precise weather insights, this site is a must-have for city life
            </p>
          </div>
          <div class="card">
            <div class="image">
              <img className='setim' src={people2} alt="" />
            </div>
            <p class="name">Sophia</p>

            <p>
            Navigate cities effortlessly with live maps and stay informed with accurate weather forecasts - a must for urban adventurers!
            </p>
          </div>
          <div class="card">
            <div class="image">
              <img className='setim' src={people3} alt="" />
            </div>
            <p class="name">Isabella</p>

            <p>
            Detailed maps and reliable weather data make this site indispensable for city dwellers. A must-have for urban exploration!
            </p>
          </div>
        </div>

        <div class="contact" id='contact'>
          <div class="image">
            <img src={customer} alt="" />
          </div>
          <div class="title">
            <h2>Be a part of the next big thing</h2>
            <p>
            A determined and compassionate professional striving to make a positive impact in her community through education and advocacy.
            </p>

            <button>contact us</button>
          </div>
        </div>
      </section>
    </main>
    <footer class="footer">
      <div class="stuff">
        <h3>CityDashboard</h3>
        <p>Urban Insights: Your City Dashboard</p>
      </div>
      <div class="stuff">
        <h3>Resources</h3>
        <p>Guides</p>
        <p>Blog</p>
        <p>Customer stories</p>
        <p>Glossary</p>
      </div>
      <div class="stuff">
        <h3>Company</h3>
        <p>AboutUs</p>
        <p>Career</p>
        <p>Partners</p>
        <p>contact Us</p>
      </div>
      <div class="stuff">
        <h3>Social Media</h3>
        <p>Linkedin</p>
        <p>Facebook</p>
        <p>Instagram</p>
        <p>Twitter</p>
      </div>
    </footer>

      
    </>
  )
}

export default Landing
