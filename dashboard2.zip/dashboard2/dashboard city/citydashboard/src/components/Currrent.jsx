import React from 'react'
import '../App.css';

function Currrent({ weatherData }) {
    const fetchLocation = () => {
        // Logic to fetch current location
        // This could be a call to a geolocation API or any other method
        // For now, let's just set a default location
        checkWeather("rajpura");
    };
  return (
    <>
    <div className="col-lg m-4 p-5 upperleft">
        <h2>Now</h2>
        <div className="livedata img-temp flex justify-content">
            <h4 className="temp" id="temp"><sup/>{weatherData.current?.temp_c}°c</h4>
            <span><img id="icon" className="wheather-icon" src={weatherData.current?.condition.icon}  alt={weatherData.current?.condition.text}/></span>
        </div>
        <div className="data_current">
            <p className="imagetext" id="text">{weatherData.current?.condition.text}</p>
                <div className="current-location">
                    <div className="containlocation">
                        <button onClick={fetchLocation} ><i className="fa-solid fa-location-crosshairs"></i>  Current Location</button>
                    </div>
                </div>
        </div>
        <span className="flex justify-content3"><i className="fa-regular fa-calendar"></i><p className="datecurrent" id="currentdate">{weatherData.current?.last_updated}</p></span>
        <span className="flex justify-content3"><i className="fa-solid fa-location-dot"></i><p className="locationcurrent" id="currentcity">{weatherData.location?.name}, {weatherData.location?.region}, {weatherData.location?.country}</p></span>
    </div>
      
    </>
  )
}

export default Currrent
